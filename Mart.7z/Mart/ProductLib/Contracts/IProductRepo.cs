﻿namespace ProductLib
{
    public interface IProductRepo : IRepo<Product>
    {
    }
}
