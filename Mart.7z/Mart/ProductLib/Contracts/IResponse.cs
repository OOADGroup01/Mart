﻿namespace ProductLib;

public interface IResponse
{
    public string? Id { get; set; }
}
