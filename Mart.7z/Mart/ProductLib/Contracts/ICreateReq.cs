﻿namespace ProductLib
{
    public interface ICreateReq
    {

    }
}
