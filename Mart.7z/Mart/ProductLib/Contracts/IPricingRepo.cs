﻿namespace ProductLib
{
    public interface IPricingRepo : IRepo<Pricing> { }

}
