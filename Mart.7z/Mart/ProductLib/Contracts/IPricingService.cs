﻿namespace ProductLib
{
    public interface IPricingService: IService<PricingResponse, PricingCreateReq, PricingUpdateReq> { }
}
