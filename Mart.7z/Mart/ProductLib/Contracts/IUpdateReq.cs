﻿namespace ProductLib
{
    public interface IUpdateReq
    {

    }
}
