﻿namespace ProductLib;

public class PricingBase
{
    public double Value { get; set; } = default!;
}
