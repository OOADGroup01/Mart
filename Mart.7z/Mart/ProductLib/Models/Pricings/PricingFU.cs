﻿namespace ProductLib;

public class PricingFU
{
    public List<PricingReqFC>? Createds { get; set; }
    public List<PricingReqFU>? Updateds { get; set; }
    public List<string>? Deleteds { get; set; }
}
