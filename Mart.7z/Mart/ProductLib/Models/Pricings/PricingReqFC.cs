﻿namespace ProductLib;

public class PricingReqFC
    : PricingBase
    //, ICreateReq
{
    public DateTime? EffectedFrom { get; set; } = default;
}
