﻿namespace ProductLib;

public class ProductBase
{
    public string? Name { get; set; } = default;
}